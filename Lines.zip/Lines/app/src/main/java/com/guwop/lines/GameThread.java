package com.guwop.lines;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Message;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.SurfaceHolder;

import android.os.Handler;

import java.util.LinkedList;
import java.util.Random;

public class GameThread extends Thread{

    public static final int NO_FILL = 0;
    public static final int NEXT_TURN = 1;
    public static final int KEEP_TURN = 2;
    public static final int GAME_OVER = 3;

    public static final int NOT_READY = -1;
    public static final int P1_TURN = 1000;
    public static final int P2_TURN = 1001;
    public static final int AI_TURN = 1002;
    public static final int P1_WIN = 2000;
    public static final int P2_WIN = 2001;
    public static final int AI_WIN = 2002;
    public static final int TIE = 2003;

    private boolean isInitialized;
    private boolean isRunning;
    private boolean isPaused;
    private int gameState;
    private int gameType;

    private Handler handler;

    /** Handle to the surface manager object we interact with */
    private SurfaceHolder surfaceHolder;

    /** Handle to the application context, used to e.g. fetch Drawables. */
    private Context context;

    private Random randy;

    private Paint paint;

    private Player[] players;
    private int turn_count;

    private int rows;
    private int columns;

    private Square [][] squares;
    private Line [] lines;

    private Confetti [] confetti_array;
    private Bitmap confetti_bitmap;
    private int confetti_width;

    private int height;
    private int width;

    private float squarelength;
    private float linewidth;
    private float linelength;
    private float header_length;

    private RectF scoreboard1;
    private RectF scoreboard2;

    private LinkedList<Line> ai_move_list;
    private Line ai_last_turn;
    private Line ai_next_move;
    private int insight;

    private Bitmap ai_last_turn_marker;
    private float ai_turn_marker_x;
    private float ai_turn_marker_y;
    private Bitmap brain;

    private long ai_turn_start_time;
    private long ai_hand_move_start;


    public GameThread(SurfaceHolder surfaceHolder_in, Context context_in,  int r, int c , Player p1, Player p2, int gt){

        isInitialized = false; //this is for when the actual board is created;
        width = 0;
        height = 0;
        isRunning = false;
        isPaused = false;
        gameType = gt;
        gameState = NOT_READY;

        //handler = handler_in;
        context = context_in;
        surfaceHolder = surfaceHolder_in;

        randy = new Random();

        players = new Player[2];
        players[0] = p1;
        players[1] = p2;

        turn_count = 1;

        rows = r;
        columns = c;

        squares = new Square[rows][columns];
        lines = new Line[((rows + 1) * columns + rows * (columns + 1))];

        paint = new Paint();
        paint.setAntiAlias(true);
        paint.setDither(true);

        paint.setStyle(Paint.Style.FILL);

        paint.setTextSize(72);
        paint.setTextAlign(Paint.Align.CENTER);

        insight=0;

        ai_move_list = new LinkedList<Line>();
        ai_last_turn_marker = BitmapFactory.decodeResource(context.getResources(), R.drawable.point_finger);
        ai_last_turn = null;
        ai_next_move = null;

        brain = BitmapFactory.decodeResource(context.getResources(), R.drawable.brain);

    }

    public void initializeBoard(){

        int h = height;
        int w = width;

        float margin=.07f;

        squarelength = ((1-margin)*w)/(columns+.2f);

        linewidth = .2f*squarelength;
        linelength = .8f*squarelength;

        header_length = h - linelength*rows - linewidth*(rows+1) - margin*w/2;

        ai_last_turn = new Line(new RectF(width/2-1, header_length + (height-header_length)/2f - 1,width/2+1 ,header_length + (height-header_length)/2f + 1));

        ai_turn_marker_x = ai_last_turn.rect.centerX();
        ai_turn_marker_y = ai_last_turn.rect.centerY();

        ai_last_turn_marker = Bitmap.createScaledBitmap(ai_last_turn_marker, (int) (width/rows *(.99)),(int) (linewidth/.2), true );

        brain = Bitmap.createScaledBitmap(brain,(int) (width*.6), (int)(width*.45), true);

        scoreboard1 = new RectF(0,0,w/2,header_length*.95f);
        scoreboard2 = new RectF(w/2,0, w,header_length*.95f);

        int line_index = 0;

        RectF temp;

        for (float r = 0; r <= rows ; r++) {
            for (float c = 0; c <= columns ; c++) {

                //vertical
                if (r < rows ) {
                    temp = new RectF(c * squarelength + w * margin/2, r * squarelength + header_length + linewidth, c * squarelength + linewidth+ w * margin/2, r * squarelength + linelength+ header_length + linewidth);
                    lines[line_index] = new Line(temp);
                    line_index++;
                }

                //horizontal
                if (c < columns ) {
                    temp = new RectF(c * squarelength + linewidth+ w * margin/2, r * squarelength + header_length , c * squarelength + linewidth+ w * margin/2 + linelength , r * squarelength + header_length + linewidth);
                    lines[line_index] = new Line(temp);
                    line_index++;
                }
            }
        }

        for (int r = 0; r < rows ; r++) {
            for (int c = 0; c < columns; c++) {

                squares[r][c] = new Square();

                if (r < rows - 1) {
                    squares[r][c].setLeft(lines[r * (columns * 2 + 1) + 2 * c]);
                    squares[r][c].setUp(lines[r * (columns * 2 + 1) + 1 + 2 * c]);
                    squares[r][c].setRight(lines[r * (columns * 2 + 1) + 2 + 2 * c]);
                    squares[r][c].setDown(lines[(r + 1) * (columns * 2 + 1) + 1 + 2 * c]);
                } else {
                    squares[r][c].setLeft(lines[r * (columns * 2 + 1) + 2 * c]);
                    squares[r][c].setUp(lines[r * (columns * 2 + 1) + 1 + 2 * c]);
                    squares[r][c].setRight(lines[r * (columns * 2 + 1) + 2 + 2 * c]);
                    squares[r][c].setDown(lines[(rows * (columns + 1) + rows * columns + c)]);
                }
            }
        }

        isInitialized = true;
        gameState = P1_TURN;
    }

    public void run(){

        while(isRunning){

            if (isInitialized ==false && width > 0)
                    initializeBoard();
            else if (isInitialized && !isPaused)
            {
                Canvas c = null;

            try {
                c = surfaceHolder.lockCanvas(null);

                drawBoard(c);

                if (gameType == MainScreen.SINGLE_PLAYER && turn_count>1)
                drawAIhand(c);

                if (gameState == AI_TURN) {

                    if (System.currentTimeMillis() - ai_turn_start_time < 2000) { //just started or renew turn - show brain
                        drawAIthink(c);
                    }
                    else if (ai_move_list.isEmpty()) { //dont have any moves, so make some
                        doAIturn();
                        ai_next_move = null;

                    }
                    else { //has moves in queue, so execute if ready

                        while (ai_next_move == null && !ai_move_list.isEmpty()) { //pick next move
                            Log.d("movelistlength", String.valueOf(ai_move_list.size()));
                            ai_next_move = ai_move_list.getFirst();
                            ai_hand_move_start = System.currentTimeMillis();
                        }


                        if (ai_next_move == ai_last_turn) //if they have met each other, then do the actual work
                        {
                            int result = handleTouchEvent(ai_next_move.rect.centerX(), ai_next_move.rect.centerY());

                            ai_move_list.removeFirst();

                            ai_next_move = null;

                            Log.d("result", String.valueOf(result));

                            //ai_turn_start_time = System.currentTimeMillis();

                            if (result == KEEP_TURN && ai_move_list.isEmpty())
                                doAIturn();
                        }
                    }
                } else if (gameState == P1_WIN || gameState == P2_WIN ) {

                    if (confetti_bitmap == null)
                        initialize_confetti();

                    drawConfetti(c);

                } else if (gameState == TIE)
                {
                    //
                }
            } finally {
                // do this in a finally so that if an exception is thrown
                // during the above, we don't leave the Surface in an
                // inconsistent state
                if (c != null) {
                    surfaceHolder.unlockCanvasAndPost(c);
                }
            }// end finally block

            }
        }

    }

    public void drawBoard(Canvas canvas){

        canvas.drawColor(Color.WHITE);

        //draw lines loop
        for (int x =0; x<((rows + 1) * columns + rows * (columns + 1)); x++){

            paint.setColor(lines[x].color);
            canvas.drawRect(lines[x].rect, paint);

            /* line debug
            paint.setTextSize(30);
            paint.setColor(Color.RED);
            canvas.drawText(String.valueOf(x), lines[x].rect.centerX(), lines[x].rect.centerY(), paint);
            */
        }

        //draw squares loop
        for (int r = 0; r < rows ; r++) {
            for (int c = 0; c < columns; c++) {
                paint.setColor(squares[r][c].color);
                canvas.drawRect(squares[r][c].rect,paint);
            }
        }

        paint.setColor(players[0].getFill_color());
        canvas.drawRect(scoreboard1,paint);

        paint.setColor(players[1].getFill_color());
        canvas.drawRect(scoreboard2,paint);

        paint.setColor(players[0].getFill_color());

        //canvas.drawRect(inner_scoreboard1 ,paint);

        paint.setColor(Color.WHITE);

        paint.setTextSize(72);
        canvas.drawText(players[0].getName(), scoreboard1.centerX(), scoreboard1.centerY()*.5f, paint);
        canvas.drawText(players[1].getName(), scoreboard2.centerX(), scoreboard2.centerY()*.5f, paint);

        paint.setTextSize(144);
        canvas.drawText(String.valueOf(players[0].getScore()), scoreboard1.centerX(), scoreboard1.centerY()*1.6f, paint);
        canvas.drawText(String.valueOf(players[1].getScore()), scoreboard2.centerX(), scoreboard2.centerY()*1.6f, paint);

        //paint.setTextSize(40);
        //paint.setColor(Color.RED);
        //canvas.drawText(String.valueOf(insight), width/2, scoreboard1.centerY(), paint);

    }

    private void drawAIthink(Canvas canvas)  {
        canvas.drawBitmap(brain, width/2f -brain.getWidth()*.5f,header_length + (height-header_length)/2f - brain.getHeight()/2f, paint );
    }

    private void drawAIhand(Canvas canvas){

        if (ai_next_move == null){
            canvas.drawBitmap(ai_last_turn_marker, ai_last_turn.rect.centerX(), ai_last_turn.rect.centerY(), paint);
            return;
        }

        float delta;
        float move_time;
        float total_distance;

        total_distance = (float) (Math.sqrt( Math.pow(ai_last_turn.rect.centerX() - ai_next_move.rect.centerX(),2) + Math.pow(ai_last_turn.rect.centerY() - ai_next_move.rect.centerY(),2)));

        if( total_distance/(squarelength*Math.sqrt(2)) < 1.5)
            move_time = 1000;
        else if( total_distance/(squarelength*Math.sqrt(2)) < 3.5)
            move_time = 2000;
        else
            move_time = 3000;

        delta = Math.min(System.currentTimeMillis() - ai_hand_move_start, move_time);

        ai_turn_marker_x = (ai_next_move.rect.centerX() - ai_last_turn.rect.centerX()) / move_time * (delta) + ai_last_turn.rect.centerX();
        ai_turn_marker_y = (ai_next_move.rect.centerY() - ai_last_turn.rect.centerY()) / move_time * (delta) + ai_last_turn.rect.centerY();

        if( Math.abs( ai_next_move.rect.centerX() - ai_turn_marker_x) < 5  && Math.abs(ai_next_move.rect.centerY() - ai_turn_marker_y) < 5 )
        {
            canvas.drawBitmap(ai_last_turn_marker, ai_next_move.rect.centerX(), ai_next_move.rect.centerY(), paint);

            ai_turn_marker_x = ai_next_move.rect.centerX();
            ai_turn_marker_y = ai_next_move.rect.centerY();

            ai_last_turn = ai_next_move;
        }else {
                canvas.drawBitmap(ai_last_turn_marker, ai_turn_marker_x, ai_turn_marker_y, paint);
        }
    }

    private void drawConfetti(Canvas canvas){

        for (int i=0; i<confetti_array.length; i++) {

            canvas.drawBitmap(confetti_bitmap, confetti_array[i].getMatrix(height, width), paint);

            if (confetti_array[i].y > 1.2 * height || confetti_array[i].x < -confetti_width*1.2 || confetti_array[i].x > width + confetti_width*1.2)
                confetti_array[i].restart(randy.nextFloat() * width - confetti_width/2,  randy.nextFloat()*height - height*1.2f);
            //confetti_array[i] = new Confetti(confetti_width, randy.nextFloat() * width - confetti_width/2,  randy.nextFloat()*height - height*1.2f, randy.nextFloat());
        }

    }

    public int handleTouchEvent(float x, float y) {

        int score;
        boolean didFillLine = false;

        score = 0;

        //Log.d("HandleTouch",String.valueOf(gameState) + "-" + String.valueOf(turn_count));

        for (int i =0; i<((rows + 1) * columns + rows * (columns + 1)); i++) {
            if (lines[i].isFilled == false && lines[i].rect.contains(x, y)) {

                lines[i].fillLine(getCurrentPlayer().getLine_color());
                didFillLine = true;

                for (int r = 0; r < rows; r++) {
                    for (int c = 0; c < columns; c++) {
                        if (squares[r][c].update(getCurrentPlayer()) == true) {

                            score++;
                        }
                    }
                }
            }
        }

        if (didFillLine == false)
            return NO_FILL;

        else if (didFillLine && score==0) {
            turn_count++;

            if (gameType == MainScreen.SINGLE_PLAYER && gameState == P1_TURN){
                ai_turn_start_time = System.currentTimeMillis();
                gameState = AI_TURN;
            }
            else if (gameType == MainScreen.SINGLE_PLAYER && gameState == AI_TURN)
                gameState = P1_TURN;
            else if (gameType == MainScreen.TWO_PLAYER && gameState == P1_TURN)
                gameState = P2_TURN;
            else //has to be two player with gamestate as p2_turn
                gameState = P1_TURN;

            Message msg = handler.obtainMessage();

            Bundle b = new Bundle();
            b.putInt("Current Player Color", getCurrentPlayer().getFill_color());

            msg.setData(b);
            handler.sendMessage(msg);

            return NEXT_TURN;
        }
        else if (score > 0 && allSquaresFilled() == false) {

            players[(turn_count - 1) % 2].addPoints(score);
            return KEEP_TURN;
        }
        else if (score>0 && allSquaresFilled() == true) {

            players[(turn_count - 1) % 2].addPoints(score);

            Message msg = handler.obtainMessage();
            Bundle b = new Bundle();

            if (players[0].getScore() > players[1].getScore()) {
                gameState = P1_WIN;
                b.putInt("Current Player Color", players[0].getFill_color());
                msg.setData(b);
                handler.sendMessage(msg);
                initialize_confetti();
            }
            else if (players[0].getScore() < players[1].getScore()){
                gameState = P2_WIN;
                b.putInt("Current Player Color", players[1].getFill_color());
                msg.setData(b);
                handler.sendMessage(msg);
                initialize_confetti();
            }
            else {
                gameState = TIE;
                b.putInt("Current Player Color", Color.DKGRAY);
                msg.setData(b);
                handler.sendMessage(msg);
            }

            return GAME_OVER;
        }
        else
            return -99;

    }


    public void setSurfaceSize(int w, int h) {
        // synchronized to make sure these all change atomically
        synchronized (surfaceHolder) {
            width = w;
            height = h;
        }
    }

    public void setGameState (int in){
        synchronized (surfaceHolder) {
            gameState = in;
        }
    }

    public void setRunning(boolean b) {
        synchronized (surfaceHolder) {
            isRunning = b;
        }
    }

    public boolean isInitialized() {
        return isInitialized;
    }

    public Player getCurrentPlayer() {
        return players[(turn_count-1) % 2];
    }

    private boolean allSquaresFilled() {

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < columns; c++) {
                if (squares[r][c].isFilled() == false) {
                    return false;
                }
            }
        }
        return true;
    }

    public int getGameState() {
        synchronized (surfaceHolder) {
            return gameState;
        }
    }

    public void pause() {
        isPaused = true;
    }

    public void unpause() {
        isPaused = false;
    }

    public void doAIturn() {

        AIMove aiMove = new AIMove(squares, lines, rows, columns);

        ai_move_list = aiMove.find_scoring_moves();

        if (ai_move_list.size() == 0) {
            aiMove = new AIMove(squares, lines, rows, columns);
            ai_move_list = aiMove.find_defensive_move();
        }

        //trim nulls
        while (ai_move_list.contains(null))
        ai_move_list.remove(null);


    }

    public void setHandler(Handler handler_in) {

        handler = handler_in;

    }

    private void initialize_confetti (){


        int color;

        if(gameState == P1_WIN){
            color = players[0].getFill_color();
        }else{
            color = players[1].getFill_color();
        }

        if (color == ContextCompat.getColor(context,R.color.lightMagenta))
            confetti_bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.magenta);
        else if(color == ContextCompat.getColor(context,R.color.lightOrange))
            confetti_bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.orange);
        else if(color == ContextCompat.getColor(context,R.color.lightYellow))
            confetti_bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.yellow);
        else if(color == ContextCompat.getColor(context,R.color.lightGreen))
            confetti_bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.green);
        else if(color == ContextCompat.getColor(context,R.color.cyan))
            confetti_bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.cyan);
        else if(color == ContextCompat.getColor(context,R.color.lightPurple))
            confetti_bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.purple);
        else
            confetti_bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.brain);

        confetti_width = (int)(squarelength*.4);

        confetti_bitmap = Bitmap.createScaledBitmap(confetti_bitmap,confetti_width, confetti_width,true);

        confetti_array = new Confetti[80];

        for (int i = 0; i<confetti_array.length; i++){

            confetti_array[i] = new Confetti(confetti_width, randy.nextFloat() * width - confetti_width/2,  randy.nextFloat()*height - height*1.2f, randy.nextFloat());
        }

    }


}


