package com.guwop.lines;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class GameBoardSurface extends SurfaceView implements SurfaceHolder.Callback {

    public static final int NO_FILL = 0;
    public static final int NEXT_TURN = 1;
    public static final int KEEP_TURN = 2;
    public static final int GAME_OVER = 3;

    private SurfaceHolder surfaceHolder;

    private GameThread gameThread;

    public GameBoardSurface(Context context, int r, int c ,Player p1, Player p2, int gt) {
        super(context);

        surfaceHolder = getHolder();

        surfaceHolder.addCallback(this);

        gameThread = new GameThread(surfaceHolder, context,r,c,p1,p2,gt);

        setFocusable(true);

    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        // start the thread here so that we don't busy-wait in run()
        // waiting for the surface to be created

        gameThread.setRunning(true);
        gameThread.start();

    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        gameThread.setSurfaceSize(width,height);
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean retry = true;

        gameThread.setRunning(false);

        while (retry) {
            try {
                gameThread.join();
                retry = false;

            } catch (InterruptedException e) {

            }
        }
    }

    /**
     * Standard window-focus override. Notice focus lost so we can pause on
     * focus lost. e.g. user switches to take a call.
     */
    @Override
    public void onWindowFocusChanged(boolean hasWindowFocus) {
        if (!hasWindowFocus) {
            if (gameThread != null)
                gameThread.pause();
        } else if (hasWindowFocus)
            gameThread.unpause();
    }

    public GameThread getThread() {
        return gameThread;
    }


}
