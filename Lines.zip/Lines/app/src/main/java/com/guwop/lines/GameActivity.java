package com.guwop.lines;

import android.app.Activity;
import android.app.usage.UsageEvents;
import android.content.Context;
import android.content.Intent;
import android.drm.DrmStore;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.LinearLayout;
import android.widget.TextView;

import static android.view.KeyEvent.KEYCODE_BACK;

public class GameActivity extends Activity implements View.OnTouchListener {

    private GameThread gameThread;
    private GameBoardSurface gameBoardSurface;

    private int gameType;

    private Player player1;
    private Player player2;

    private Handler thread_handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();

        gameType = intent.getIntExtra(MainScreen.GAME_TYPE, -99);

        player1 = new Player(intent.getStringExtra(MainScreen.PLAYER1_NAME), intent.getIntExtra(MainScreen.PLAYER1_LINE_COLOR, Color.BLACK), intent.getIntExtra(MainScreen.PLAYER1_FILL_COLOR, Color.BLACK));
        player2 = new Player(intent.getStringExtra(MainScreen.PLAYER2_NAME), intent.getIntExtra(MainScreen.PLAYER2_LINE_COLOR, Color.BLACK), intent.getIntExtra(MainScreen.PLAYER2_FILL_COLOR, Color.BLACK));
        //gameBoard = new GameBoard(this, 6, 5 , player1, player2);

        gameBoardSurface = new GameBoardSurface(this, 6, 5, player1, player2, gameType);
        gameBoardSurface.setOnTouchListener(this);
        setContentView(gameBoardSurface);

        gameThread = gameBoardSurface.getThread();

        thread_handler = new Handler() {

            public void handleMessage(Message m) {

                int color = m.getData().getInt("Current Player Color");

                if (color != 0)
                    getWindow().setStatusBarColor(color);

            }//end handle msg
        };

        gameThread.setHandler(thread_handler);

        getWindow().setStatusBarColor(gameThread.getCurrentPlayer().getFill_color());

    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {


        if (event.getAction() == MotionEvent.ACTION_UP && gameThread.getGameState() != GameThread.NOT_READY && gameThread.getGameState() != GameThread.AI_TURN) {
            gameThread.handleTouchEvent(event.getX(), event.getY());
        }

        return true;

    }

    @Override
    public void onBackPressed() {
        boolean retry = true;

        gameThread.setRunning(false);

        while (retry) {
            try {
                gameThread.join();
                retry = false;

            } catch (InterruptedException e) {
            }
        }

        finish();

    }

}