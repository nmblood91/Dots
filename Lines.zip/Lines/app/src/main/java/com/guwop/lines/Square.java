package com.guwop.lines;

import android.graphics.Color;
import android.graphics.RectF;

public class Square {

    public Line left;
    public Line right;
    public Line up;
    public Line down;
    public RectF rect;
    private boolean isFilled;
    public int color;



    public Square(){
        isFilled = false;
        rect = new RectF();
        color = Color.WHITE;
    }

    public Square(Square toCopy){
        isFilled = toCopy.isFilled;
        rect = new RectF(toCopy.rect);
        color = toCopy.color;
    }

    public void setLeft(Line l){
        left = l;
        rect.left=l.rect.right;
        return;
    }

    public void setRight(Line l){
        right = l;
        rect.right = l.rect.left;
        return;
    }

    public void setUp(Line l){
        up = l;
        rect.top = l.rect.bottom;
        return;
    }

    public void setDown(Line l) {
        down = l;
        rect.bottom = l.rect.top;
        return;
    }

    public boolean update(Player player){

        if (this.isFilled == false && up.isFilled && down.isFilled && left.isFilled && right.isFilled){
            isFilled=true;
            color=player.getFill_color();
            return true;
        }

        return false;
    }

    public boolean isFilled(){
        return  isFilled;
    }

    public int sides_filled() {

        int sides = 0;

        if (right.isFilled)
            sides++;
        if (left.isFilled)
            sides++;
        if (up.isFilled)
            sides++;
        if (down.isFilled)
            sides++;

        return sides;

    }


    //this is only called when there is only one open line
    public Line getOpenSide() {

        if (right.isFilled == false)
            return right;
        else if (left.isFilled == false)
            return left;
        else if (up.isFilled == false)
            return up;
        else if (down.isFilled == false)
            return down;
        else
            return null;
    }

    public void fillOpenSide() {
            right.isFilled = left.isFilled = up.isFilled = down.isFilled = true;
            isFilled=true;
    }


}
