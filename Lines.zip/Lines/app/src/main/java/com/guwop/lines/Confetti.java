package com.guwop.lines;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;

public class Confetti {

    public float x;
    public float y;

    private static final float pi = 3.14159265359f;
    private float drift;
    private float gravity;
    private float rotation_speed;
    private float rotation_offset;

    public float width;

    private Matrix matrix;
    private long last_confetti_draw;

    public Confetti(int w, float x_in, float y_in, float random){

        width = w;
        x=x_in;
        y=y_in;

        drift =random;
        gravity = (random %3) + 3;

        rotation_offset = random*360f;
        rotation_speed = (random %5) +3;

        matrix = new Matrix();

        last_confetti_draw = -1; //flag to be set at the first draw
    }

    public Matrix getMatrix(float screen_height, float screen_width){

        if (last_confetti_draw == -1)
            last_confetti_draw = System.currentTimeMillis();

        long now = System.currentTimeMillis();

        matrix.reset();

        y += screen_height*gravity*(now - last_confetti_draw)/25000f;

        x += (drift-.5f)*screen_width*(now - last_confetti_draw)/5000f;

        float deg;

        rotation_offset += 360f* rotation_speed*(now - last_confetti_draw)/11000f;

        //rotate around where on bitmap - the center
        matrix.postRotate(rotation_offset, width/2, width/2);

        matrix.postTranslate(x, y);

        last_confetti_draw = System.currentTimeMillis();

        return matrix;
    }


    public void restart(float new_x, float new_y) {

        x = new_x;
        y = new_y;

    }
}
