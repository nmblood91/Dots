package com.guwop.lines;
import java.util.LinkedList;
import java.util.Random;

public class AIMove
{
    //recreate the board
    private Square [][] squares;
    private Line[] lines;
    private int rows;
    private int columns;
    private Random randy;

    public AIMove (Square[][] s, Line[] l, int row, int col){

        randy = new Random();
        rows = row;
        columns = col;

        lines = new Line[((rows + 1) * columns + rows * (columns + 1))];

        for (int k = 0; k<((rows + 1) * columns + rows * (columns + 1)); k++ )
            lines[k] = new Line(l[k]);


        squares = new Square[rows][columns];

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < columns; c++) {
                squares[r][c] = new Square(s[r][c]);

                if (r < rows - 1) {
                    squares[r][c].setLeft(lines[r * (columns * 2 + 1) + 2 * c]);
                    squares[r][c].setUp(lines[r * (columns * 2 + 1) + 1 + 2 * c]);
                    squares[r][c].setRight(lines[r * (columns * 2 + 1) + 2 + 2 * c]);
                    squares[r][c].setDown(lines[(r + 1) * (columns * 2 + 1) + 1 + 2 * c]);
                } else {
                    squares[r][c].setLeft(lines[r * (columns * 2 + 1) + 2 * c]);
                    squares[r][c].setUp(lines[r * (columns * 2 + 1) + 1 + 2 * c]);
                    squares[r][c].setRight(lines[r * (columns * 2 + 1) + 2 + 2 * c]);
                    squares[r][c].setDown(lines[(rows * (columns + 1) + rows * columns + c)]);
                }

            }
        }

    }

    public LinkedList<Line> find_defensive_move() {

        LinkedList<Line> defensive_moves = new LinkedList<Line>();
        LinkedList<Line> move_list = new LinkedList<Line>();

        AIMove hypothetical;

        int lowest_cede = rows*columns;
        int turn_cede;

        for (int k = 0; k<((rows + 1) * columns + rows * (columns + 1)); k++ ) {
            if (lines[k].isFilled == false) {

                hypothetical = new AIMove(this.squares,this.lines,this.rows,this.columns);

                hypothetical.lines[k].fillLine();

                turn_cede = hypothetical.find_scoring_moves().size();

                if (turn_cede < lowest_cede) {
                    defensive_moves = new LinkedList<Line>();
                    defensive_moves.add(lines[k]);
                    lowest_cede = turn_cede;

                }else if (turn_cede == lowest_cede) {
                    defensive_moves.add(lines[k]);
                }

                lines[k].unFillLine();
            }
        }

        move_list.add(defensive_moves.get(randy.nextInt(defensive_moves.size())));

        return move_list;
    }


    public LinkedList<Line> find_scoring_moves() {

        int sides_filled;
        LinkedList<Line> scoring_moves;
        LinkedList<Line> move_list = new LinkedList<Line>();

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < columns; c++) {
                if (squares[r][c].isFilled() == false) {

                    sides_filled = squares[r][c].sides_filled();

                    if (sides_filled == 3) { //can fill a square. do recursive method to see how many you could get

                        scoring_moves = find_runs(r, c, move_list, this);

                        if (scoring_moves.size() > move_list.size())
                            move_list = scoring_moves;

                    }
                }

            }
        }

        return move_list;

    }

    private LinkedList<Line> find_runs(int r, int c, LinkedList<Line> move_list, AIMove aiMove){

        if (r < 0 || r >=aiMove.rows || c < 0 || c >=aiMove.columns) //avoid bounds
            return move_list;
        else if (aiMove.squares[r][c].sides_filled() == 3 || (aiMove.squares[r][c].sides_filled() == 4 && aiMove.squares[r][c].isFilled() == false) ) { //found another scoring move
            Line move = aiMove.squares[r][c].getOpenSide();
            aiMove.squares[r][c].fillOpenSide();
            move_list.add(move);

            LinkedList<Line> temp_list;
            temp_list = find_runs(r + 1, c, move_list,aiMove); //look up

            if (temp_list.size() > move_list.size()) //check to see if its better than before
                move_list = temp_list;

            temp_list = find_runs(r - 1, c, move_list,aiMove); //look down

            if (temp_list.size() > move_list.size())
                move_list = temp_list;

            move_list = find_runs(r, c + 1, move_list,aiMove); // look right

            if (temp_list.size() > move_list.size())
                move_list = temp_list;

            move_list = find_runs(r, c - 1, move_list,aiMove); //look left

            if (temp_list.size() > move_list.size())
                move_list = temp_list;
        }

        return move_list;

        }


}
