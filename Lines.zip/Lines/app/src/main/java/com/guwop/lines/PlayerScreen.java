package com.guwop.lines;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

public class PlayerScreen extends AppCompatActivity implements View.OnClickListener {

    private ConstraintLayout background;
    private EditText namebox;
    private ImageView pickcolortext;
    private ImageView[] colors = new ImageView[6];
    private ImageView submit;


    private int line_color;
    private int fill_color;
    private int prior_selected_color; //fill color
    private String name;
    private Resources resources;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.player_screen);

        Intent in = getIntent();

        resources = getResources();
            
        background = (ConstraintLayout) findViewById(R.id.playerscreenview);

        pickcolortext = (ImageView) findViewById(R.id.pickacolortext);

        namebox = (EditText) findViewById(R.id.playerName);

        colors[0]= (ImageView) findViewById(R.id.magenta);
        colors[1]= (ImageView) findViewById(R.id.orange);
        colors[2]= (ImageView) findViewById(R.id.yellow);
        colors[3]= (ImageView) findViewById(R.id.green);
        colors[4]= (ImageView) findViewById(R.id.cyan);
        colors[5]= (ImageView) findViewById(R.id.purple);

        if(in.hasExtra("fill_color"))
            prior_selected_color = in.getIntExtra("fill_color",0);
        else
            prior_selected_color = -1;


            if (prior_selected_color == ContextCompat.getColor(this,R.color.lightMagenta))
                colors[0].setImageResource(R.drawable.unavailable);
            else if(prior_selected_color == ContextCompat.getColor(this,R.color.lightOrange))
                colors[1].setImageResource(R.drawable.unavailable);
            else if(prior_selected_color == ContextCompat.getColor(this,R.color.lightYellow))
                colors[2].setImageResource(R.drawable.unavailable);
            else if(prior_selected_color == ContextCompat.getColor(this,R.color.lightGreen))
                colors[3].setImageResource(R.drawable.unavailable);
            else if(prior_selected_color == ContextCompat.getColor(this,R.color.cyan))
                colors[4].setImageResource(R.drawable.unavailable);
            else if(prior_selected_color == ContextCompat.getColor(this,R.color.lightPurple))
                colors[5].setImageResource(R.drawable.unavailable);


        for (int i =0; i<6; i++){
            colors[i].setOnClickListener(this);
        }

        namebox.setVisibility(View.INVISIBLE);

        submit= (ImageView) findViewById(R.id.submitbutton);
        submit.setVisibility(View.INVISIBLE);
        submit.setOnClickListener(this);

    }


    @Override
    public void onClick(View v) {
        int id = v.getId();

        switch (id) {

            case R.id.magenta:

                line_color = ContextCompat.getColor(this,R.color.deepMagenta);
                fill_color = ContextCompat.getColor(this,R.color.lightMagenta);

                if (fill_color == prior_selected_color)
                    break;

                background.setBackgroundColor(fill_color);
                getWindow().setStatusBarColor(fill_color);
                namebox.setVisibility(View.VISIBLE);
                pickcolortext.setVisibility(View.INVISIBLE);
                submit.setImageDrawable(getResources().getDrawable(R.drawable.magentasubmit,null));
                submit.setVisibility(View.VISIBLE);
                
                break;

            case R.id.orange:

                line_color = ContextCompat.getColor(this,R.color.deepOrange);
                fill_color = ContextCompat.getColor(this,R.color.lightOrange);

                if (fill_color == prior_selected_color)
                    break;

                background.setBackgroundColor(fill_color);
                getWindow().setStatusBarColor(fill_color);
                namebox.setVisibility(View.VISIBLE);
                pickcolortext.setVisibility(View.INVISIBLE);
                submit.setImageDrawable(getResources().getDrawable(R.drawable.orangesubmit,null));
                submit.setVisibility(View.VISIBLE);

                break;

            case R.id.yellow:
                line_color= ContextCompat.getColor(this,R.color.deepYellow);
                fill_color = ContextCompat.getColor(this,R.color.lightYellow);

                if (fill_color == prior_selected_color)
                    break;

                background.setBackgroundColor(fill_color);
                getWindow().setStatusBarColor(fill_color);
                namebox.setVisibility(View.VISIBLE);
                pickcolortext.setVisibility(View.INVISIBLE);
                submit.setImageDrawable(getResources().getDrawable(R.drawable.yellowsubmit,null));
                submit.setVisibility(View.VISIBLE);

                break;

            case R.id.green:

                line_color=ContextCompat.getColor(this,R.color.deepGreen);
                fill_color = ContextCompat.getColor(this,R.color.lightGreen);

                if (fill_color == prior_selected_color)
                    break;

                background.setBackgroundColor(fill_color);
                getWindow().setStatusBarColor(fill_color);
                namebox.setVisibility(View.VISIBLE);
                pickcolortext.setVisibility(View.INVISIBLE);
                submit.setImageDrawable(getResources().getDrawable(R.drawable.greensubmit,null));
                submit.setVisibility(View.VISIBLE);

                break;

            case R.id.cyan:

                line_color= ContextCompat.getColor(this,R.color.deepBlue);
                fill_color = ContextCompat.getColor(this,R.color.cyan);

                if (fill_color == prior_selected_color)
                    break;

                background.setBackgroundColor(fill_color);
                getWindow().setStatusBarColor(fill_color);
                namebox.setVisibility(View.VISIBLE);
                pickcolortext.setVisibility(View.INVISIBLE);
                submit.setImageDrawable(getResources().getDrawable(R.drawable.bluesubmit,null));
                submit.setVisibility(View.VISIBLE);

                break;

            case R.id.purple:

                line_color = ContextCompat.getColor(this,R.color.deepPurple);
                fill_color = ContextCompat.getColor(this,R.color.lightPurple);

                if (fill_color == prior_selected_color)
                    break;

                background.setBackgroundColor(fill_color);
                getWindow().setStatusBarColor(fill_color);
                namebox.setVisibility(View.VISIBLE);
                pickcolortext.setVisibility(View.INVISIBLE);
                submit.setImageDrawable(getResources().getDrawable(R.drawable.purplesubmit,null));
                submit.setVisibility(View.VISIBLE);

                break;

            case R.id.submitbutton:

                    name = namebox.getText().toString();

                    Intent intent = new Intent();

                    intent.putExtra("line_color", line_color);
                    intent.putExtra("fill_color", fill_color);
                    intent.putExtra("name",name);

                    setResult(RESULT_OK, intent);
                    finish();

        }
    }
}
