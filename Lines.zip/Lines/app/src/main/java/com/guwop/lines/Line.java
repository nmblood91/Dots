package com.guwop.lines;

import android.graphics.Color;
import android.graphics.RectF;

public class Line {

    public RectF rect;
    public int color;
    public boolean isFilled;

    public Line(RectF r){
        isFilled=false;
        rect =r;
        color = Color.LTGRAY;
    }

    public Line(Line toCopy){

        isFilled = toCopy.isFilled;
        rect = new RectF(toCopy.rect);
        color = toCopy.color;
    }

    public void fillLine(int c){
        color =c;
        isFilled=true;
    }

    public void fillLine() {
        isFilled =true;
    }

    public void unFillLine(){
        isFilled = false;
    }

    public void setColor(int c){
        color = c;
    }


}
