package com.guwop.lines;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;


public class MainScreen extends AppCompatActivity {
    public static final String PLAYER1_NAME = "com.guwop.lines.PLAYER1_NAME";
    public static final String PLAYER1_LINE_COLOR = "com.guwop.lines.PLAYER1_COLOR";
    public static final String PLAYER1_FILL_COLOR = "com.guwop.lines.PLAYER1_FILL_COLOR";
    public static final String PLAYER2_NAME = "com.guwop.lines.PLAYER2_NAME";
    public static final String PLAYER2_LINE_COLOR = "com.guwop.lines.PLAYER2_LINE_COLOR";
    public static final String PLAYER2_FILL_COLOR = "com.guwop.lines.PLAYER2_FILL_COLOR";
    public static final String GAME_TYPE = "com.guwop.lines.GAME_TYPE";
    public static final int SINGLE_PLAYER = 111;
    public static final int TWO_PLAYER = 222;

    final int SINGLE_PLAYER_REQUEST_CODE = 777;
    final int TWO_PLAYER1_REQUEST_CODE = 778;
    final int TWO_PLAYER2_REQUEST_CODE = 779;

    Intent game_intent;
    Intent player_intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);

        game_intent = new Intent(this, GameActivity.class);
    }

    public void singlePlayer(View view) {

        game_intent.putExtra(GAME_TYPE,SINGLE_PLAYER);

        player_intent = new Intent(this, PlayerScreen.class);
        player_intent.putExtra("Player#","P1");
        startActivityForResult(player_intent, SINGLE_PLAYER_REQUEST_CODE);

    }

    public void twoPlayer(View view) {

        game_intent.putExtra(GAME_TYPE,TWO_PLAYER);

        player_intent = new Intent(this, PlayerScreen.class);
        player_intent.putExtra("Player#","P1");
        startActivityForResult(player_intent, TWO_PLAYER1_REQUEST_CODE);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == SINGLE_PLAYER_REQUEST_CODE) {

            if (resultCode == RESULT_OK) {

                String name = data.getStringExtra("name");

                if (name == null || name.length() ==0) {
                    name = "Player 1";
                }

                game_intent.putExtra(PLAYER1_NAME, name);
                game_intent.putExtra(PLAYER1_FILL_COLOR, data.getIntExtra("fill_color",Color.BLACK));
                game_intent.putExtra(PLAYER1_LINE_COLOR, data.getIntExtra("line_color",Color.BLACK));

                game_intent.putExtra(PLAYER2_NAME, "AI");
                game_intent.putExtra(PLAYER2_FILL_COLOR, Color.DKGRAY);
                game_intent.putExtra(PLAYER2_LINE_COLOR, Color.BLACK);

                startActivity(game_intent);

            }

        }

        if (requestCode == TWO_PLAYER1_REQUEST_CODE) {

            if (resultCode == RESULT_OK) {

                String name = data.getStringExtra("name");

                if (name == null || name.length() ==0)
                    name = "Player 1";

                game_intent.putExtra(PLAYER1_NAME, name);
                game_intent.putExtra(PLAYER1_FILL_COLOR, data.getIntExtra("fill_color",Color.BLACK));
                game_intent.putExtra(PLAYER1_LINE_COLOR, data.getIntExtra("line_color",Color.BLACK));


                player_intent = new Intent(this, PlayerScreen.class);
                player_intent.putExtra("Player#","P2");
                player_intent.putExtra("fill_color",data.getIntExtra("fill_color",Color.BLACK));
                startActivityForResult(player_intent,TWO_PLAYER2_REQUEST_CODE);

            }

        }

        if (requestCode == TWO_PLAYER2_REQUEST_CODE){

            if (resultCode == RESULT_OK) {

                String name = data.getStringExtra("name");

                if (name == null || name.length() ==0)
                    name = "Player 2";

                game_intent.putExtra(PLAYER2_NAME, name);
                game_intent.putExtra(PLAYER2_FILL_COLOR, data.getIntExtra("fill_color",Color.BLACK));
                game_intent.putExtra(PLAYER2_LINE_COLOR, data.getIntExtra("line_color",Color.BLACK));

                startActivity(game_intent);

            }

        }
    }
}




