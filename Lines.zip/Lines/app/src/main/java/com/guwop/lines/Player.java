package com.guwop.lines;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;

class Player {

    private String name;
    private int line_color;
    private int fill_color;
    private int score;

    public Player (String n, int lc, int fc)
    {
       name= n;
       line_color = lc;
       fill_color = fc;
       score = 0;
    }

    public boolean equals (Player other){

        return this.line_color == other.getLine_color();

    }

    public void addPoints(int s)
    {
        score+=s;
    }
    public String getName() {
        return name;
    }
    public int getFill_color() { return fill_color; }
    public int getLine_color() { return line_color; }
    public int getScore() {
        return score;
    }


}
